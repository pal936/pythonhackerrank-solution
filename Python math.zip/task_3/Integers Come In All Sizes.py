#!/usr/bin/env python
# coding: utf-8

# In[1]:


a = int(input())
b = int(input())
c = int(input())
d = int(input())
print((a**b)+(c**d))


# In[ ]:




