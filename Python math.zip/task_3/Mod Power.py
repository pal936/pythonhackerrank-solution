#!/usr/bin/env python
# coding: utf-8

# In[1]:


a = int(input())
b = int(input())
c = int(input())
print(pow(a,b))
print(pow(a,b,c))


# In[ ]:




