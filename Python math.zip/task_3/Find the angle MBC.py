#!/usr/bin/env python
# coding: utf-8

# In[1]:


import math
AB = int(input())
BC = int(input())
H = (math.sqrt(AB**2 + BC**2))/2
adj = BC/2
result = int(round(math.degrees(math.acos(adj/H))))
print(str(result)+ chr(176))


# In[ ]:




