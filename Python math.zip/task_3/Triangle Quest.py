#!/usr/bin/env python
# coding: utf-8

# In[1]:


for i in range(1,int(input())):
    print(int(i * 10**i / 9))


# In[ ]:




