#!/usr/bin/env python
# coding: utf-8

# In[1]:


import cmath
n = complex(input())
a = complex(n)
print(cmath.polar(a)[0])
print(cmath.polar(a)[1])


# In[ ]:




