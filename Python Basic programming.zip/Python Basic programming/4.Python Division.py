#!/usr/bin/env python
# coding: utf-8

# ### 4.Python: Division

# In[1]:


a = int(input())
b = int(input())
print(a,'//',b,'=',a//b)
print(a,'/',b,'=',a/b)

