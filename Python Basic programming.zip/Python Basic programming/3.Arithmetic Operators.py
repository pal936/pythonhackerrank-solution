#!/usr/bin/env python
# coding: utf-8

# ### 3.Arithmetic Operators

# In[2]:


a = int(input())
b = int(input())
print(a+b)
print(a-b)
print(a*b)
    

