#!/usr/bin/env python
# coding: utf-8

# ### 5.Loops

# In[1]:


n = int(input())
for i in range(n):
    print(i*i)

