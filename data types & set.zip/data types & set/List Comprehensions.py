#!/usr/bin/env python
# coding: utf-8

# ### List Comprehensions

# In[1]:


X = int(input())
Y = int(input())
Z = int(input())
N = int(input())
p = [[p, r, a] for p in range(X + 1) for r in range(Y + 1) for a in range(Z + 1) if p + r + a != N]
print(p)

