#!/usr/bin/env python
# coding: utf-8

# ### Check Strict Superset

# In[1]:


pp = set(input().split())
N = int(input())
output = True
for i in range(N):
    r = set(input().split())
    if not r.issubset(pp):
        output = False
    if len(r) >= len(pp):
        output = False
print(output)

