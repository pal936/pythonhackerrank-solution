#!/usr/bin/env python
# coding: utf-8

# ### Symmetric Difference

# In[1]:


numbers1 = int(input())
s1 = set(map(int,input().split()))
numbers2 = int(input())
s2 = set(map(int,input().split()))
s3 = (s1.difference(s2)).union(s2.difference(s1))
for i in sorted(list(s3)):
    print(i)

