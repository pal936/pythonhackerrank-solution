#!/usr/bin/env python
# coding: utf-8

# ### No Idea!

# In[1]:


n,m=list(map(int, input().split()))
pp=list(map(int, input().split()))
h=set(map(int, input().split()))
r=set(map(int, input().split()))
res=0
for x in pp:
    if x in h:
        res+=1
    elif x in r:
        res-=1
print(res)

