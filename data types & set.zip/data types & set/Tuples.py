#!/usr/bin/env python
# coding: utf-8

# ### Tuples

# In[1]:


if __name__ == '__main__':
    n = int(input())
    a = tuple(map(int, input().split(' ')))
    print(hash(a))

