#!/usr/bin/env python
# coding: utf-8

# ### Introduction to Sets

# In[1]:


def average(array):
    s=set(array)
    return sum(s)/len(s)


if __name__ == '__main__':
    pp = int(input())
    alll = list(map(int, input().split()))
    result = average(alll)
    print(result)
                 

