#!/usr/bin/env python
# coding: utf-8

# ### Set .add()

# In[1]:


N=int(input())
a=[]
for i in range(0,N):
    r=input()
    a.append(r)
print(len(set(a)))

