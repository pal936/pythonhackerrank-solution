#!/usr/bin/env python
# coding: utf-8

# ### The Captain's Room

# In[3]:


p= int(input())
a = map(int, input().split())
a = sorted(a)
print(a[-1])

