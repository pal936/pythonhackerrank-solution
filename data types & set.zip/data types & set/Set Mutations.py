#!/usr/bin/env python
# coding: utf-8

# ### Set Mutations

# In[2]:


pt = int(input())
storage = set(map(int, input().split()))
pra = int(input())
for i in range(pra):
    operation = input().split()
    if operation[0] == 'intersection_update':
        a = set(map(int, input().split()))
        storage.intersection_update(a)
    elif operation[0] == 'update':
        a = set(map(int, input().split()))
        storage.update(a)
    elif operation[0] == 'symmetric_difference_update':
        a = set(map(int, input().split()))
        storage.symmetric_difference_update(a)
    elif operation[0] == 'difference_update':
        a = set(map(int, input().split()))
        storage.difference_update(a)
    else :
        pass

print(sum(storage))

