#!/usr/bin/env python
# coding: utf-8

# ### Lists

# In[1]:


if __name__ == '__main__':
    N = int(input())
    pp = []
    for i in range(0,N):
        inputs=input().split();
        if inputs[0] == "insert":
            pp.insert(int(inputs[1]),int(inputs[2]))
        elif inputs[0] == "append":
            pp.append(int(inputs[1]))
        elif inputs[0] == "pop":
            pp.pop()
        elif inputs[0] == "print":
            print(pp)
        elif inputs[0] == "remove":
            pp.remove(int(inputs[1]))
        elif inputs[0] == "sort":
            pp.sort()
        else:
            pp.reverse()

