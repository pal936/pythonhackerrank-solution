#!/usr/bin/env python
# coding: utf-8

# ### Check Subset

# In[1]:


for i in range(int(input())):
    p = int(input())
    r = set(input().split()) 
    a = int(input())
    s = set(input().split())
    print(r.issubset(s))
                        

