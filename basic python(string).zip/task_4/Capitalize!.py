#!/usr/bin/env python
# coding: utf-8

# In[20]:


s = input()
print(s.title())


# In[ ]:




