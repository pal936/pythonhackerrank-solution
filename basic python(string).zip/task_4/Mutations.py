#!/usr/bin/env python
# coding: utf-8

# In[1]:


def mutate_string(string, position, character):
    a = list(string)
    a[position] = character;
    result = ''.join(a);
    return result

if __name__ == '__main__':
    s = input()
    i, c = input().split()
    s_new = mutate_string(s, int(i), c)
    print(s_new)


# In[ ]:




