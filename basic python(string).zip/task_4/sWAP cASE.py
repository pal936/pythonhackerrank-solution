#!/usr/bin/env python
# coding: utf-8

# In[1]:


def swap_case(s):
    x = s.swapcase()
    return x
if __name__ == '__main__':
    s = input()
    result = swap_case(s)
    print(result)


# In[ ]:




